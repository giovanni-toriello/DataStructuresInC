#include <stdio.h>
#include <stdlib.h>
#include "lista.h"
#include "item.h"

lista cancFinoItem(lista l,item e);
lista fondiDaItem(lista l1,lista l2, item e);

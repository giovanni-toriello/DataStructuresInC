
typedef struct oggetto* item;

int eq(item x, item y);
item input_item();
item newItem(int intero);
void output_item(item x);

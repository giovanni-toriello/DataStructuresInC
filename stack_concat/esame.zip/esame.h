
#include "stack.h"

void inserisci(stack uno, stack due);